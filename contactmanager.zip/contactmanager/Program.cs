// Define DEFAULT or ALT DEFAULT based on conditional compilation
#define DEFAULT // ALT DEFAULT

// Conditionally compile the code based on NEVER, DEFAULT, or ALT
#if NEVER
    // Your code goes here if NEVER is defined
#elif DEFAULT
// Code section for DEFAULT case

// Setting up the initial application builder
using ContactManager.Authorization;
using ContactManager.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Retrieving connection string from configuration
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

// Adding the database context to services
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString));
builder.Services.AddDatabaseDeveloperPageExceptionFilter();

// Configuring default identity with options
builder.Services.AddDefaultIdentity<IdentityUser>(
    options => options.SignIn.RequireConfirmedAccount = true)
    .AddRoles<IdentityRole>() // Adding roles
    .AddEntityFrameworkStores<ApplicationDbContext>(); // Storing in the database context

builder.Services.AddRazorPages(); // Adding Razor Pages support

// Configuring authorization policies
builder.Services.AddAuthorization(options =>
{
    options.FallbackPolicy = new AuthorizationPolicyBuilder()
        .RequireAuthenticatedUser() // Requiring authenticated users by default
        .Build();
});

// Adding custom authorization handlers
builder.Services.AddScoped<IAuthorizationHandler, ContactIsOwnerAuthorizationHandler>();
builder.Services.AddSingleton<IAuthorizationHandler, ContactAdministratorsAuthorizationHandler>();
builder.Services.AddSingleton<IAuthorizationHandler, ContactManagerAuthorizationHandler>();

var app = builder.Build(); // Building the application

// Database migration and seeding initial data
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var context = services.GetRequiredService<ApplicationDbContext>();
    context.Database.Migrate(); // Applying any pending migrations

    // Seeding initial data (requires Microsoft.Extensions.Configuration)
    var testUserPw = builder.Configuration.GetValue<string>("SeedUserPW");
    await SeedData.Initialize(services, testUserPw); // Initializing seed data
}

// Handling different environments
if (app.Environment.IsDevelopment())
{
    app.UseMigrationsEndPoint(); // Enabling the endpoint for migrations in development
}
else
{
    app.UseExceptionHandler("/Error"); // Handling exceptions with a specified endpoint
    app.UseHsts(); // Using HTTP Strict Transport Security (HSTS)
}

// Rest of the middleware pipeline setup
app.UseHttpsRedirection(); // Redirecting HTTP requests to HTTPS
app.UseStaticFiles(); // Serving static files
app.UseRouting(); // Enabling routing
app.UseAuthentication(); // Authenticating users
app.UseAuthorization(); // Authorizing access based on policies
app.MapRazorPages(); // Mapping Razor Pages

app.Run(); // Running the application

#elif ALT
    // Code section for ALT case
    
    // Setting up the initial application builder
    var builder = WebApplication.CreateBuilder(args);

    // Retrieving connection string from configuration
    var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

    // Adding the database context to services
    builder.Services.AddDbContext<ApplicationDbContext>(options =>
        options.UseSqlServer(connectionString));
    builder.Services.AddDatabaseDeveloperPageExceptionFilter();

    // Configuring default identity with options
    builder.Services.AddDefaultIdentity<IdentityUser>(
        options => options.SignIn.RequireConfirmedAccount = true)
        .AddRoles<IdentityRole>() // Adding roles
        .AddEntityFrameworkStores<ApplicationDbContext>(); // Storing in the database context

    builder.Services.AddRazorPages(); // Adding Razor Pages support

    // Configuring controllers with an authorization policy
    builder.Services.AddControllers(config =>
    {
        var policy = new AuthorizationPolicyBuilder()
                         .RequireAuthenticatedUser() // Requiring authenticated users for controllers
                         .Build();
        config.Filters.Add(new AuthorizeFilter(policy)); // Applying authorization filter to controllers
    });

    var app = builder.Build(); // Building the application

    // Initializing seed data for the database
    using (var scope = app.Services.CreateScope())
    {
        var services = scope.ServiceProvider;
        SeedData.Initialize(services); // Initializing seed data for the database
    }

    // Handling different environments
    if (app.Environment.IsDevelopment())
    {
        app.UseMigrationsEndPoint(); // Enabling the endpoint for migrations in development
    }
    else
    {
        app.UseExceptionHandler("/Error"); // Handling exceptions with a specified endpoint
        app.UseHsts(); // Using HTTP Strict Transport Security (HSTS)
    }

    // Rest of the middleware pipeline setup
    app.UseHttpsRedirection(); // Redirecting HTTP requests to HTTPS
    app.UseStaticFiles(); // Serving static files
    app.UseRouting(); // Enabling routing
    app.UseAuthentication(); // Authenticating users
    app.UseAuthorization(); // Authorizing access based on policies
    app.MapRazorPages(); // Mapping Razor Pages

    app.Run(); // Running the application
#endif